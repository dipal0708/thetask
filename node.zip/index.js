const express = require('express');
const fs = require('fs');
const https = require('https');

var http = require('http'); 
// const privateKey = fs.readFileSync('/etc/letsencrypt/live/vps260154.vps.ovh.ca/privkey.pem','utf8');
// const certificate = fs.readFileSync('/etc/letsencrypt/live/vps260154.vps.ovh.ca/cert.pem','utf8');
// const credentials = {
//         key: privateKey,
//         cert: certificate
// }; 

//const app = express();
var app = express();

//const httpsServer = https.createServer(credentials, app);
//var io = require('socket.io')(httpsServer);
//var io = require('socket.io')(app);


const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const mongodb = require('mongodb');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const v = require('node-input-validator');
const morgan = require('morgan');
const jwt = require('jsonwebtoken');
const readline = require('readline');
const { google } = require('googleapis');
const config = require('./config');
var VerifyToken = require('./verifyToken');
const nodemailer = require('nodemailer');



var publicDir = require('path').join(__dirname, '//uploads//');
app.use(express.static(publicDir));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }))
app.use(bodyParser.json({ limit: '50mb' }));
var os = require("os");
var hostname = os.hostname();
const SCOPES = ['https://www.googleapis.com/auth/contacts.readonly'];
const TOKEN_PATH = 'token.json';

var transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false, 
  service: 'gmail',
  auth: {
    user: 'thetaskwiz@gmail.com',
    pass: 'TaskWiz@3030'
  }
});


// app.use(function (req, res, next) {
//  res.setHeader('Access-Control-Allow-Origin', 'https://www.thetaskwiz.com','https://thetaskwiz.com');
// res.setHeader('Access-Control-Allow-Methods', 'POST');
//  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,x-access-token');
//  res.setHeader('Access-Control-Allow-Credentials', true);
//  next();
// });


app.use(function (req, res, next) {
  var allowedOrigins = ['https://www.thetaskwiz.com', 'https://thetaskwiz.com', 'http://localhost:4200'];
  var origin = req.headers.origin;
  if (allowedOrigins.indexOf(origin) > -1) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  res.setHeader('Access-Control-Allow-Methods', 'POST');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,x-access-token');
  res.setHeader('Access-Control-Allow-Credentials', true);
  return next();
});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html')
  // Note: __dirname is directory that contains the JavaScript source code. Try logging it and see what you get!
  // Mine was '/Users/zellwk/Projects/demo-repos/crud-express-mongo' for this app.
})



app.post('/api/authenticate', (req, res) => {

  db.collection('users').findOne({ email: req.body.email })
    .then(function (result) {
      if (result) {
        const JWTToken = jwt.sign({
          email: result.email,
          _id: result._id
        },
          config.secret,
          {
            expiresIn: '300h'
          });

        return res.status(200).json({
          success: 'true',
          token: JWTToken,
          _id: result._id,
          organizerRecord: req.body
        });
      } else {
        db.collection('users').insertOne(req.body, (err, response) => {

          if (err) {
            return response.send({
              success: 'false',
              msg: "Not Registered"
            })
          } else {
            const JWTToken = jwt.sign({
              email: response.email,
              _id: response.insertedId
            },
              config.secret,
              {
                expiresIn: '300h'
              });
            return res.status(200).json({
              success: 'true',
              token: JWTToken,
              _id: response.insertedId,
              organizerRecord: req.body
            });
          }
        });
      }
    });
});

app.post('/api/getContactList', VerifyToken, function (req, res) {
  // Load client secrets from a local file.
  fs.readFile('client_secret.json', (err, content) => {
    if (err) return console.log('Error loading client secret file:', err);
    // Authorize a client with credentials, then call the Google Tasks API.
    authorize(JSON.parse(content), listConnectionNames);
  });
})

app.post('/api/getshareemail', VerifyToken, function (req, res) {

  db.collection('shareBoard').find({ $and: [{ boardid: req.body.boardid }, { uid: req.body.uid }] }).toArray(function (err, results) {
    if (err) {
      return res.status(200).json({
        success: 'false',
        msg: "Something went wrong"
      })
    } else {
      res.status(200).json({
        success: 'true',
        message: 'share email Data ',
        results: results
      })
    }
  })
})

app.post('/api/getpublicurldata', VerifyToken, function (req, res) {

  db.collection('publicurl').find({ $and: [{ boardid: req.body.boardid }, { userid: req.body.userid }] }).toArray(function (err, results) {
    if (err) {
      return res.status(200).json({
        success: 'false',
        msg: "Something went wrong"
      })
    } else {
      res.status(200).json({
        success: 'true',
        msg: 'Publicurl data',
        results: results
      })
    }
  })
})


app.post('/api/addpublicurl', VerifyToken, function (req, res) {

  db.collection('publicurl').find({ $and: [{ boardid: req.body.boardid }, { userid: req.body.userid }, { index: req.body.index }] }).toArray(function (err, results) {

    if (err) {
      return res.status(200).json({
        success: 'false',
        msg: "Something went wrong"
      })
    } else {
      if (results.length > 0) {
        res.status(200).json({
          success: 'false',
          msg: "already generated publicurl"
        })
      } else {
        db.collection('publicurl').insertOne(req.body, (err, results) => {
          if (err) {
            return res.status(200).json({
              success: 'false',
              msg: "Record not saved"
            })
          } else {
            res.status(200).json({
              success: 'true',
              msg: "Url generated succussfully"
            })
          }
        });
      }
    }
  })
})

app.post('/api/pushShareEmail', VerifyToken, function (req, res) {
  debugger
  db.collection('shareBoard').find({ $and: [{ boardid: req.body.boardid }, { email: req.body.email }] }).toArray(function (err, results) {

    if (err) {
      return res.status(200).json({
        success: 'false',
        msg: "Something went wrong"
      })
    } else {
      if (results.length > 0) {
        res.status(200).json({
          success: 'false',
          msg: "This baord you aleready share with this email"
        })
      } else {
        db.collection('shareBoard').insertOne(req.body, (err, results) => {
          if (err) {
            return res.status(200).json({
              success: 'false',
              msg: "Record not saved"
            })
          } else {
            var htmlData = '<h1>Taskwiz</h1><p>Please click on below link to access the work board</p>';
            htmlData += '<a href=' + req.body.link + '>Click Here</a>';

            var mailOptions = {
              from: 'thetaskwiz@gmail.com',
              to: req.body.email,
              subject: 'Taskwiz Share a work board.',
              html: htmlData,
            };

            transporter.sendMail(mailOptions, function (error, info) {

              if (error) {
                console.log("this is error", error)
                res.status(200).json({
                  success: 'false',
                  msg: "Email not sent"
                })
              } else {
                console.log("this is info", info)
                res.status(200).json({
                  success: 'true',
                  msg: "Email sent succussfully"
                })
              }
            });
          }
        })
      }
    }
  });
})


app.post('/api/addBoardName', VerifyToken, function (req, res) {
  const boardData = {
    board_title: req.body.title,
    id: req.body.id,
  };
  db.collection('boardNameMaster').insertOne(boardData, (err, results) => {
    if (err) return console.log(err)

    var objectid = results.insertedId;

    res.status(200).json({
      success: 'true',
      id: objectid,
      msg: "New Board Saved"
    })
  })
});

app.post('/api/getBoardData', VerifyToken, (req, res) => {

  db.collection('boardNameMaster').find({ id: req.body.id }).toArray(function (err, results) {

    if (err) {
      return res.send({
        success: 'false',
        message: 'No board Found',
      });
    } else {
      res.status(200).send({
        success: 'true',
        message: 'Board Data ',
        results: results
      })
    }
  })
});

app.post('/api/getPantangoneData', VerifyToken, (req, res) => {

  db.collection('boardMaster').find({ userid: req.body.id }).toArray(function (err, results) {

    if (err) {
      res.send({
        success: 'false',
        message: 'Error found',
      })
    } else {
      var data = [];
      for (var i = 0; i < results.length; i++) {
        data[i] = [];
        for (var j = 0; j < results[i].maindata.length; j++) {
          var tmp = results[i].maindata[j].innerdata.length;
          var getPers = Math.min(15 * (tmp + 1), 100) + "%";
          data[i].push({ 'pipe': getPers });
        }
      }
      res.status(200).send({
        success: 'true',
        message: 'Pantagone Data ',
        results: data
      })

    }

  })
})


app.post('/api/getShareBoard', (req, res) => {

  db.collection('boardMaster').findOne({ boardid: req.body.boardid })
    .then(function (doc) {
      if (doc) {
        res.send({
          success: 'true',
          message: 'data',
          results: doc
        })
      } else {
        res.send({
          success: 'false',
          message: 'no data'
        })
      }

    })
})


app.post('/api/saveBoardData', VerifyToken, (req, res) => {
  db.collection('boardMaster').findOne({ boardid: req.body.boardid })

    .then(function (result) {

      if (result) {
        db.collection('boardMaster').updateOne(
          { boardid: req.body.boardid }, { $set: { maindata: req.body.maindata, bkccolor: req.body.bkccolor, setting: req.body.setting } }
          , function (err, result) {
            res.status(200).json({
              success: 'true',
              msg: "Updated"
            })
          });
      } else {
        db.collection('boardMaster').insertOne(req.body, (err, results) => {
          if (err) return console.log(err)

          res.status(200).json({
            success: 'true',
            msg: "Saved"
          })
        })
      }
    })
});


app.post('/api/changetitle', VerifyToken, (req, res) => {

  db.collection('boardNameMaster').updateOne(
    { _id: new mongodb.ObjectID(req.body.boardid) },
    { $set: { "board_title": req.body.title } }
    , function (err, result) {

      if (err) return console.log(err)

      res.status(200).json({
           success: 'true',
        msg: "Updated",
        title: req.body.title
      })
    });
})
app.post('/api/getBoard', VerifyToken, (req, res) => {
  db.collection('boardMaster').findOne({ boardid: req.body.boardid })
    .then(function (doc) {
      if (doc) {
        res.send({
          success: 'true',
          message: 'data',
          results: doc
        })
      } else {
        res.send({
          success: 'false',
          message: 'no data'
        })
      }
    })
})

app.post('/api/savepublicurldata', (req, res) => {
  console.log(req.body);
  if (!req.body.userdata) {
    return res.send({
      success: 'false',
      message: 'Enter Userdata'
    })
  }

  db.collection('boardMaster').find({ $and: [{ boardid: req.body.userdata.boardid }, { userid: req.body.userdata.userid }] }).toArray((err, results) => {
    var data = results[0].maindata[req.body.userdata.index].innerdata.length;
    var cardData = req.body.card;
    cardData.boardid = results[0].maindata[req.body.userdata.index].innerdata[data - 1].boardid;
    cardData.list = results[0].maindata[req.body.userdata.index].innerdata[data - 1].list;
    results[0].maindata[req.body.userdata.index].innerdata.push(cardData);
    console.log(results[0].maindata[req.body.userdata.index].innerdata);

    db.collection('boardMaster').updateOne(
      { boardid: req.body.userdata.boardid }, { $set: { maindata: results[0].maindata } }
      , function (err, result) {
        if (err) return res.status(200).json({ success: 'false', msg: "Public card not Added" })
        res.status(200).json({
          success: 'true',
          msg: "Public card Added successfully"
        })
      });
  })
})

app.post('/api/deleteBoard', VerifyToken, (req, res) => {

  db.collection('boardNameMaster').deleteOne({ _id: new mongodb.ObjectID(req.body.boardid) });
  db.collection('boardMaster').deleteOne({ "boardid": req.body.boardid });
  res.send({
    success: 'true',
    message: 'deleted'
  })
})

app.post('/api/unsharedata', VerifyToken, (req, res) => {
  db.collection('shareBoard').deleteOne({ _id: new mongodb.ObjectID(req.body._id) }, (err, result) => {
    if (err) return res.status(200).json({ success: 'false', msg: "Not deleted" })
    res.send({
      success: 'true',
      message: 'unShare successfully'
    })

  });
})

//  

var db;
MongoClient.connect('mongodb+srv://taskwiz:Taskwiz1234@cluster0-y4lib.mongodb.net', { useUnifiedTopology: true }, (err, client) => {
  if (err) return console.log(err)
  db = client.db('board') // whatever your database name is
  // httpsServer.listen(4200, () => {
    var server =  app.listen(3000, () => {
    console.log('listening on 3000')
  })
//var server = http.createServer(app);
var io = require('socket.io').listen(server);

io.on('connection',(socket)=>{
  console.log('new connection made.');

  socket.on('join', function(data){
    //joining
    console.log("socket" , data);
    
    socket.join(data.room);

    console.log(data.user + 'joined the room : ' + data.room);

    socket.broadcast.to(data.room).emit('new user joined', {user:data.user, message:'has joined this room.'});
  });


  socket.on('leave', function(data){
  
    console.log(data.user + 'left the room : ' + data.room);

    socket.broadcast.to(data.room).emit('left room', {user:data.user, message:'has left this room.'});

    socket.leave(data.room);
  });

  socket.on('message',function(data){

    io.in(data.room).emit('new message', {user:data.user, message:data.message});
  })

});
  
})
