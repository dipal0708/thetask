module.exports = {
    'secret': 'Taskwiz'
  };