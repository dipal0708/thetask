import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../services/auth.services';
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from 'ngx-toastr';

declare var $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  txtstatus : boolean = false;
  txtdashboardname : string;
  boraddata:any = [];
  pipeData:any = [];
  delCurrentIndex: number;
  delname: string;
  deltype: string;
  mainarr: any = [];
  board_id: string;
  color: string = '#364f6b';
  statusdata: any = [];
  typedata: any = [];

  constructor(private ts : ToastrService,private spinner: NgxSpinnerService,private router: Router,private auths : Auth) {

   }

  ngOnInit() {
    this.getBoard();  
  }



  addnewdashboard(){
      this.txtstatus = true;
this.setFocus()
  }
  setFocus() {
    setTimeout(() => {
      $("#autof").focus();
    }, 10);
  }
  createdaashboard(){
        if(this.txtdashboardname){
            this.addTitleName(this.txtdashboardname);
         //  this.router.navigate(['board',this.txtdashboardname,1]);
        } 
  }
  clkcancel(){
    this.txtstatus = false;
  }
  addTitleName(val){
    this.spinner.show();
    this.auths.adddashboardtitle(val).subscribe(data => { if(data['success'] ==='true'){  this.router.navigate(['board',this.txtdashboardname,data['id']]); } else { console.log('something went wrong'); } }, error => { console.log(error); })
  }

  getBoard(){
    this.spinner.show();
    this.auths.getBoardData().subscribe(data => { if(data['success'] ==='true'){ 
      
      this.boraddata = data['results'];
      console.log("data",this.boraddata);
      
      this.getPantagoneDataFunc();
     } else { console.log('something went wrong'); this.spinner.hide(); } }, error => { console.log(error); this.spinner.hide();})
  }
 

 
  getPantagoneDataFunc(){
    this.auths.getPantagoneData().subscribe(data => { if(data['success'] ==='true'){ 
      this.spinner.hide();   
      for(var i =0 ; i <  this.boraddata.length ; i++){
          this.boraddata[i].pipe = data['results'][i];
         
          
      }
      
     } else { console.log('something went wrong'); this.spinner.hide(); } }, error => { console.log(error); this.spinner.hide();})
  }


  // openDeletePop(_id) {
    
  //   $('.deletePopContainer').show();
  // }

  // saveData() {
  //   //this.spinner.show();
  //   var uid = localStorage.getItem('id');
  //   const tmpdata = {
  //     'boardid': this.board_id,
  //     'maindata': this.mainarr, userid: uid,
  //     'bkccolor': this.color,
  //     'setting': {
  //       'status': this.statusdata, 'type': this.typedata,
  //     }
  //   };
  //   this.auths.saveBoardData(tmpdata).subscribe(data => { this.sendMessage(); }, error => { console.log(error); this.ts.error(error); })
  // }

  // delColumn() {
  //   if (this.deltype === 'mainboard') {
  //     this.delwholebaord();
  //   } else if (this.deltype === 'col') {
  //     this.mainarr.splice(this.delCurrentIndex, 1);
  //     $('.deletePopContainer').hide();
  //    // this.saveData();
  //   }
  // }

  delwholebaord(_id) {
    this.spinner.show();
    this.auths.deleteboard(_id).subscribe(data => { if (data['success']) {this.getBoard()}})

  }
}
