import { Component, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Auth } from '../services/auth.services';
import { RealtimeService } from '../realtime.service';
import dayGridPlugin from '@fullcalendar/daygrid';
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from 'ngx-toastr';
import { environment } from 'src/environments/environment';
import { ChatService } from '../services/chat.service';
declare var $: any;


@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.css']
})

export class BoardComponent implements OnInit {

  imgurl: string = environment.imgUrl;
  name: string;
  statusbtn: boolean = true;
  statustxt: boolean = false;
  addcard: any = [];
  editColumname: any = [];
  cardtextbox: any = [];
  txtcardtitle: any = [];
  carddata: string;
  txttitle: string;
  carddataarr: any = [];
  mainarr: any = [];
  board_id: string;
  currentIndex: number;
  currentIndexMain: number;
  color: string = '#364f6b';
  color1: string = '#fff';
  ctitle: boolean = false;
  txttitlename: string;
  model: NgbDateStruct;
  date: { year: number, month: number };
  closeResult: any;
  ownername: string = '';
  listarr = [];
  calenderarr = [];
  viewstatus: string = 'kanban';
  calendarPlugins = [dayGridPlugin];
  lstright: string;
  txtshareemail: string;
  uid: string;
  lstaccess: string;
  access: string;
  shareemailData = [];
  txtcolumntitle: any = [];
  editboxCol: any = [];
  listbln: boolean = false;
  calenderbln: boolean = false;
  kanbanView: boolean = true;
  publicurl: string;
  setUpCurrentIndex: number;
  publiclist = [];
  delname: string;
  delCurrentIndex: number;
  deltype: string;
  selectedIndex: number = 1;
  statusdata: any = [];
  typedata: any = [];
  groupbyvalue: string = '';
  listData = [];
  groupbystatusarr = [];
  colorbln :boolean = false;
  messageText:String;
  displaychat: boolean = false;
  settingcolor: any = [{ name: 'c1', color: '#e920e9' },
  { name: 'c2', color: '#000' },
  { name: 'c3', color: '#fff500' },
  { name: 'c4', color: '#e920e9' },
  { name: 'c5', color: '#2889e9' },
  { name: 'c6', color: '#rgb(236,64,64)' },
  { name: 'c7', color: '#2889e9' },
  { name: 'c8', color: '#fff500' },
  { name: 'c9', color: '#e920e9' },
  { name: 'c10', color: '#2889e9' },
  { name: 'c11', color: '#fff500' },
  { name: 'c12', color: '#e920e9' }];

  messageArray:Array<{user:String,message:String}> = [];
  // settingcolor: any = [ '#000','#fffff','#000000'];

  public ProductHeader = [{ name: 'Default' }, { name: 'Apple' }, { name: 'Excel' }, { name: 'AWS' }, { name: 'Google' }];

  constructor(private realtime: RealtimeService,private _chatService:ChatService, private ts: ToastrService, private spinner: NgxSpinnerService, private modalService: NgbModal, private calendar: NgbCalendar, private route: ActivatedRoute, private router: Router, private auths: Auth, private elementRef: ElementRef) {
    const tmpdata = JSON.parse(localStorage.getItem('currentUser'));

    this._chatService.newUserJoined()
    .subscribe(data=> this.messageArray.push(data));
    
    this._chatService.userLeftRoom()
    .subscribe(data=>this.messageArray.push(data));

    this._chatService.newMessageReceived()
    .subscribe(data=>this.messageArray.push(data));

    this.ownername = tmpdata['email'];
    this.uid = localStorage.getItem('id');
  }
  ngOnInit() {
    this.spinner.show();
    this.name = this.route.snapshot.paramMap.get('name');
    console.log("name",this.name);
    this.board_id = this.route.snapshot.paramMap.get('id');
    //localStorage.setItem("board_id", this.board_id);
    var cuser = localStorage.getItem('currentUser')
    var d =JSON.parse(cuser)
    this._chatService.joinRoom({user: d['name'], room:this.board_id});
    console.log("board_id",this.board_id);
    
    this.getData();
    this.getrealtimedata();
    this.ProductHeader

  }
  chatting(){
  this.displaychat = true;

}
chattingclose(){
  this.displaychat = false;
  
}
  sendMessagechat()
  {
    var cuser = localStorage.getItem('currentUser')
    var d =JSON.parse(cuser)
      this._chatService.sendMessage({user:d['name'], room:this.board_id, message:this.messageText});
  }


  getrealtimedata() {
    this.realtime.getMessages(this.board_id).subscribe((message: string) => {
      this.setAlldata(message);
    });
  }

  sendMessage() {
    console.log('send');
    this.realtime.sendMessage(this.board_id);
  }

  ngAfterViewInit() {
    $("ul.boardNavigationContainer > li.boardNavigationItem > a.boardMenu").click(function () {
      if ($(this).parent().hasClass("active")) {
        $("ul.boardNavigationContainer > li.boardNavigationItem.hasChild").removeClass("active");
        $("ul.boardNavigationContainer > li.boardNavigationItem ul.boardChildNavigationContainer").removeClass("slideDown");
      } else {
        $("ul.boardNavigationContainer > li.boardNavigationItem.hasChild").removeClass("active");
        $("ul.boardNavigationContainer > li.boardNavigationItem ul.boardChildNavigationContainer").removeClass("slideDown");
        $(this).parent().addClass("active");
        $(this).next().addClass("slideDown");
      }
    });

    $("ul.boardNavigationContainer > li.boardNavigationItem ul.boardChildNavigationContainer li a.boardChildMenu").click(function () {
      if ($(this).parent().parent().parent().hasClass("active")) {
        $("ul.boardNavigationContainer > li.boardNavigationItem.hasChild").removeClass("active");
        $("ul.boardNavigationContainer > li.boardNavigationItem ul.boardChildNavigationContainer").removeClass("slideDown");
      }
    });
    const $menu = $("ul.boardNavigationContainer > li.boardNavigationItem > a.boardMenu");
    $(document).mouseup(e => {
      if (
        !$menu.is(e.target) && $menu.has(e.target).length === 0
      ) {
        // ... nor a descendant of the container
        $menu.parent().removeClass("active");
        $menu.next().removeClass("slideDown");
      }
    });
    /*=== Custom Popup ===*/
    var customPopEvent = $('.popEvent');
    var closePop = $(".customPopupContent > span.icon-add");

    $(customPopEvent).click(function () {
      var getPopId = $(this).attr('data-id');
      $('.customPopup').hide();
      $('.customPopup#' + getPopId).show();
    });

    $(closePop).click(function () {
      $('.customPopup').hide();
    });

    $(document).mouseup(e => {
      if (
        !$('.customPopupContent').is(e.target) && // if the target of the click isn't the container...
        $('.customPopupContent').has(e.target).length === 0 && !$menu.is(e.target) && $menu.has(e.target).length === 0
      ) {
        // ... nor a descendant of the container
        $('.customPopup').hide();
      }
    });
  }

  addlist() {
    this.statusbtn = false;
    this.statustxt = true;
  }

  addtitle() {
    if (this.txttitle) {
      this.statusbtn = true;
      this.statustxt = false;
      this.addcard[this.mainarr.length] = true;
      this.cardtextbox[this.mainarr.length] = false;
      this.mainarr.push({
        "id": this.auths.random(),
        "name": this.txttitle,
        "createdDate": Date.now(),
        "CreatedBy": "owner",
        "Owner": this.ownername,
        "color": "#fff",
        "status": "",
        "type": "",
        "dueDate": "",
        "shares": "",
        "defaults": "",
        "innerdata": []
      });
      this.mainarr.forEach((val, index) => {
        this.editColumname[index] = true;
      })
      // default list view 
      this.saveData();
      this.txttitle = '';
      if (this.groupbyvalue == 'status') {
        this.groupby('status', 2);

      }
    }
  }
  addcarddata(val) {
    this.addcard[val] = false;
    this.cardtextbox[val] = true;
    this.setFocus("autof" + val);
  }

  clkaddcard(index) {
    if (this.txtcardtitle[index]) {
      this.addcard[index] = true;
      if (!this.carddataarr[index]) {
        this.carddataarr[index] = [];
      }
      this.cardtextbox[index] = false;
      this.mainarr[index].innerdata.push({
        'textdata': this.txtcardtitle[index],
        'cardid': this.auths.random(),
        'boardid': this.board_id,
        'colid': this.mainarr[index].id,
        'createdDate': Date.now(),
        'createdBy': 'owner',
        'owner': this.ownername,
        'color': '#fff',
        'list': this.mainarr[index].name,
        'status': '',
        'dueDate': '',
        'shares': '',
        'other': '',
        'type': '',
        'link': false,
        'datepicker': false
      });
      this.saveData();
      this.txtcardtitle[index] = "";
    }
  }

  canceltxt() {
    this.statustxt = false;
    this.statusbtn = true;
  }
  cancelinnertxt(val) {
    this.addcard[val] = true;
    this.cardtextbox[val] = false;
  }

  cancelColumn(val) {
    this.editboxCol[val] = false;
    this.editColumname[val] = true;
  }

  saveData() {
    //this.spinner.show();
    var uid = localStorage.getItem('id');
    console.log("uid",uid);
    const tmpdata = {
      'boardid': this.board_id,
      'maindata': this.mainarr, userid: uid,
      'bkccolor': this.color,
      'setting': {
        'status': this.statusdata, 'type': this.typedata,
        'settingcolor': this.settingcolor
      }

      
    };

    this.auths.saveBoardData(tmpdata).subscribe(data => { this.sendMessage(); }, error => { console.log(error); this.ts.error(error); })
  }

  getData() {
    this.auths.getAllBoardData(this.board_id).subscribe(data => {
      this.setAlldata(data);
      console.log("dat12313a",data);
    }, error => { console.log(error); this.spinner.hide(); })
  }

  setAlldata(data) {
    if (data['success'] === 'true') {
      // if (data['results']['setting']['settingcolor'].length > 0) {
      //   this.settingcolor = data['results']['setting']['settingcolor'];
      // }
      this.mainarr = data['results']['maindata'];
      this.color = data['results']['bkccolor'];
      this.statusdata = data['results']['setting']['status'];
      this.typedata = data['results']['setting']['type'];

      for (var i = 0; i <= data['results']['maindata'].length; i++) {
        this.addcard[i] = true;
        this.cardtextbox[i] = false;
        this.editColumname[i] = true;
        this.editboxCol[i] = false;
      }
      this.spinner.hide();

    } else { this.spinner.hide(); this.generateArry(); }
  }


  generateArry() {
    this.statusdata = this.auths.getstatusData();
    this.typedata = this.auths.getTypeData();

    var arr = ['New', 'In Progress', 'Done'];
    const tmparr = [];
    for (var i = 0; i < arr.length; i++) {
      tmparr.push({
        "id": this.auths.random(),
        "name": arr[i],
        "createdDate": Date.now(),
        "CreatedBy": "owner",
        "Owner": this.ownername,
        "color": "#fff",
        "status": "",
        "type": "",
        "dueDate": "",
        "shares": "",
        "defaults": "",
        "innerdata": []
      })
      this.addcard[i] = true;
      this.cardtextbox[i] = false;
      this.editColumname[i] = true;
      this.editboxCol[i] = false;
    }

    tmparr[0].innerdata.push(
      {
        "textdata": "Start here",
        "cardid": this.auths.random(),
        "colid": tmparr[0].id,
        "boardid": this.board_id,
        "createdDate": 1578928366584,
        "createdBy": "owner",
        "owner": this.ownername,
        "color": "#fff",
        "list": "New",
        "status": "",
        "dueDate": "",
        "shares": "",
        "other": "",
        "type": "",
        "link": false,
        "datepicker": false
      })
    this.mainarr = tmparr;

    this.saveData();
  }
  onItemDrop(e: any, index) {
    if (index !== this.currentIndexMain) {
      if (this.groupbyvalue == 'status') {
        if (this.groupbystatusarr[index].name == 'Blank') {
          e.dragData.status = '';
        } else {
          e.dragData.status = this.groupbystatusarr[index].name;
        }
        this.groupby('status', 2);
        this.saveData();
      } else {
        this.removeItem(e.dragData, this.mainarr[this.currentIndexMain].innerdata)
        this.mainarr[index].innerdata.push(e.dragData);
        this.saveData();
      }
    }
  }

  onItemDrag(mainindex, index) {
    this.currentIndex = index;
    this.currentIndexMain = mainindex;
  }

  removeItem(item: any, list: Array<any>) {
    let index = list.map(function (e) {
      return e.textdata
    }).indexOf(item.textdata);
    list.splice(index, 1);
  }

  changcolour(e: any) {
    console.log(JSON.stringify(e))
    this.changebackgroundcolor(e);
  }


  changsettingcolor(e: any, index) {
    this.settingcolor[index].color = e;
    this.saveData();
  }
  changebackgroundcolor(color) {
    $("#mainForm").css({ 'background': color });
    this.color = color;
    //this.elementRef.nativeElement.ownerDocument.body.style.backgroundColor = color;
  }

  closecp(e: any) {
    this.color = e;
    this.saveData();
  }
  chnagetitle(name) {
    this.ctitle = true;
    this.txttitlename = name;
    this.setFocus("maintitle");
  }

  editcl(val, name) {
    this.editboxCol[val] = true;
    this.editColumname[val] = false;
    this.txtcolumntitle[val] = name;
    this.setFocus("coltitle" + val);
  }

  clkaddColumn(val) {

    this.mainarr[val].name = this.txtcolumntitle[val];
    this.editboxCol[val] = false;
    this.editColumname[val] = true;

    this.saveData();
  }
  updatetitleofpage() {
    if (this.txttitlename) {
      this.spinner.show();
      this.auths.updatetitle(this.board_id, this.txttitlename)
        .subscribe(data => {
          if (data['success'] === 'true') {
            this.ctitle = false;

            this.name = data['title'];
            this.router.navigate(['board', this.txttitlename, this.board_id]);

            this.spinner.hide();
          }
        })
    }
  }
  canceltitle() {
    this.ctitle = false;
  }
  deletemaincol(index) {
    this.mainarr.splice(index, 1);
    this.saveData();
  }

  delwholebaord() {
    this.spinner.show();
    this.auths.deleteboard(this.board_id).subscribe(data => { if (data['success']) { this.router.navigate(['dashboard']); } })
  }
  openedit(pindex, cindex) {

    document.querySelectorAll('.dropdown-menu').forEach(el => {
      el.classList.remove('show');
    });

    $(".cust").each(function (index) {
      $(this).hide();
    });
    $(".main").each(function (index) {
      $(this).show();
    });
    $("#editcontent" + pindex + cindex).show();
    $("#maincontent" + pindex + cindex).hide();

    $('#prd' + pindex + cindex).addClass('show');
    $('.boardOverlay').addClass('overlayActive');

    const $overlay = $(".boardOverlay");
    $($overlay).click(() => {
      if ($overlay.hasClass("overlayActive")) {
        // ... nor a descendant of the container
        $overlay.removeClass("overlayActive");

        this.closedropdpwnpopup();
      }
    });
    //this.setFocus("editcardfocus"+pindex+cindex);
  }
  changcolourtxt(e, pindex, cindex) {
    this.mainarr[pindex].innerdata[cindex].color = e;
    this.colorbln = false;
  }

  showcolor(){
    this.colorbln = true;
  }
  closecptxt(e, pindex, cindex) {
    this.saveData();
  }

  
  deleteinnerdata(pindex, cindex) {
    this.mainarr[pindex].innerdata.splice(cindex, 1);
    $(".boardOverlay").removeClass("overlayActive");
    this.saveData();
  }

  onBlurMethod(pindex, cindex, value) {
    this.closedropdown(pindex, cindex);
    if (value) {
      this.mainarr[pindex].innerdata[cindex].textdata = value;
      this.saveData();
    }
  }

  keyPress(event: any, pindex, cindex, value) {
    if (event.shiftKey === true && event.keyCode === 13) {
      $(this).val(function (i, val) {
        return val + '\n';
      });
    }
    else if (event.keyCode === 13) {
      this.closedropdown(pindex, cindex);
      if (value) {
        this.mainarr[pindex].innerdata[cindex].textdata = value;
        this.saveData();
      }
    }
  }

  duedate(pindex, cindex) {
    $('#datepicker' + pindex + cindex).daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 2010,
    }, (start, end, label) => {
      this.selectdate(pindex, cindex, start.format('DD-MM-YYYY'));
    });
    $('#datepicker' + pindex + cindex).click();
  }

  selectdate(pindex, cindex, d) {
    this.mainarr[pindex].innerdata[cindex].dueDate = d;
    this.closedropdown(pindex, cindex);
    this.saveData();

  }

  selectToday() {
    this.model = this.calendar.getToday();

  }

  groupby(val, indexval) {
    this.selectedIndex = indexval;
    let tmpdata = this.convertArr();

    if (val === 'status') {
      let findunique = this.uniquedata(tmpdata, 'status');
      let unique = findunique.sort();
      this.getGroupbyresult(unique, tmpdata, 'status');
      this.groupbyvalue = 'status';
      this.statusbtn = false;

    }
    else if (val === 'dueDate') {
      let findunique = this.uniquedata(tmpdata, 'dueDate');
      let unique = this.sortdate(findunique);
      this.getGroupbyresult(unique, tmpdata, 'dueDate');
    } else if (val === 'list') {
      this.groupbyvalue = '';
      this.statusbtn = true;
      this.mainarr.forEach((data, index) => {
        this.addcard[index] = true;
      });
      // this.getData();
    } else if (val === 'type') {
      let data = [];
      let findunique = this.uniquedata(tmpdata, 'type');
      let unique = findunique.sort();
      this.getGroupbyresult(unique, tmpdata, 'type');
    }
  }

  delColumn() {
    if (this.deltype === 'mainboard') {
      this.delwholebaord();
    } else if (this.deltype === 'col') {
      this.mainarr.splice(this.delCurrentIndex, 1);
      $('.deletePopContainer').hide();
      this.saveData();
    }
  }

  openDeletePop(val, name = '', type) {
    this.delCurrentIndex = val;
    this.delname = name;
    this.deltype = type;
    $('.deletePopContainer').show();
  }
  closeDeletePop() {
    this.delCurrentIndex;
    this.delname = '';
    $('.deletePopContainer').hide();
  }
  openDeleteCardPop(val, name = '', type) {
    this.delCurrentIndex = val;
    this.delname = name;
    this.deltype = type;
    $('.confirmDelCardPopWrapper').show();
    $('.custWrapper .popupContainer').addClass('showBlurBack');
  }

  closeDeleteCardPop() {
    this.delCurrentIndex;
    this.delname = '';
    $('.confirmDelCardPopWrapper').hide();
    $('.custWrapper .popupContainer').removeClass('showBlurBack');
  }

  sortdate(array) {
    let sortedActivities = array.sort((a, b) => b.date - a.date)
    return sortedActivities;
  }
  closedropdpwnpopup() {
    $(".cust").each(function (index) {
      $(this).hide();
    });
    $(".main").each(function (index) {
      $(this).show();
    });

    $(".popupWrapper").each(function (index) {
      $(this).removeClass('show').addClass('hide');
    })
  }
  convertArr() {
    let tmpdata = [];
    for (var i = 0; i < this.mainarr.length; i++) {
      for (var j = 0; j < this.mainarr[i].innerdata.length; j++) {
        tmpdata.push(this.mainarr[i].innerdata[j]);
      }
    }
    return tmpdata;
  }

  convertcalenderArr() {
    let tmpdata = [];
    for (var i = 0; i < this.mainarr.length; i++) {
      for (var j = 0; j < this.mainarr[i].innerdata.length; j++) {
        if (this.mainarr[i].innerdata[j].dueDate) {
          tmpdata.push({ 'title': this.mainarr[i].innerdata[j].textdata, 'date': this.mainarr[i].innerdata[j].dueDate });
        }
      }
    }
    return tmpdata;
  }

  getGroupbyresult(unique, tmpdata, val) {
    let liststatusarr = [];
    let data = [];

    for (var t = 0; t < unique.length; t++) {
      data[t] = [];
      for (var j = 0; j < tmpdata.length; j++) {
        if (tmpdata[j][val] === unique[t]) {
          data[t].push(tmpdata[j]);
        }
      }
    }
    for (var k = 0; k < data.length; k++) {
      if (!liststatusarr[k]) {
        liststatusarr[k] = [];
      }
      this.editColumname[k] = true;
      this.addcard[k] = false;
      liststatusarr[k].name = (!unique[k] ? 'Blank' : unique[k]);
      liststatusarr[k].innerdata = data[k];
    }
    this.groupbystatusarr = liststatusarr;

  }

  uniquedata(arr, val) {
    const unique = [...new Set(arr.map(item => item[val]))];
    return unique;
  }
  addstatus(pindex, cindex, val) {
    this.mainarr[pindex].innerdata[cindex].status = val;
    this.closedropdown(pindex, cindex);
    this.saveData();
  }
  addtype(pindex, cindex, val) {
    this.mainarr[pindex].innerdata[cindex].type = val;
    this.closedropdown(pindex, cindex);
    this.saveData();
  }
  closedropdown(pindex, cindex) {
    $(".boardOverlay").removeClass("overlayActive");
    $("#editcontent" + pindex + cindex).hide();
    $("#maincontent" + pindex + cindex).show();
    $('.dropdown-menu').removeClass('show');
  }

  listView(val) {
    this.viewstatus = val;
    if (val === 'list') {
      this.opencloseView(false, false, true);
      let tmpdata = this.convertArr();
      this.listarr = tmpdata;

    } else if (val === 'calender') {
      this.opencloseView(false, true, false);
      this.calenderarr = this.convertcalenderArr();
    } else if (val === 'kanban') {
      this.opencloseView(true, false, false);
    }
  }


  shareboard() {

    if (this.txtshareemail && this.lstaccess != undefined) {
      this.spinner.show();
      const tmp = {
        'email': this.txtshareemail,
        'access': this.lstaccess,
        'boardid': this.board_id,
        'uid': this.uid,
        'type': 'board',
        'link': environment.emailUrl + 'share/' + encodeURI(this.name) + '/' + this.board_id
      }
      this.auths.shareBoardViaEmail(tmp).subscribe(data => {
        if (data['success'] === 'true') {
          this.getshareData(); this.ts.success(data['msg']);
        } else { this.spinner.hide(); this.ts.error(data['msg']); }
      },
        error => {
          console.log(error);
          this.ts.error(error);
        })
    }
  }

  getshareData() {
    this.spinner.show();
    const tmp = {
      'boardid': this.board_id,
      'uid': this.uid
    }

    this.auths.getSharedEmail(tmp).subscribe(data => {
      if (data['success'] === 'true') {
        this.spinner.hide(); this.shareemailData = data['results'];
      } else { this.spinner.hide(); this.ts.error(data['msg']); }
    },
      error => {
        console.log(error);
        this.ts.error(error);
      })
  }
  clickoncardSharebtn(val) {
    $("#customCardPopup").show();
    this.closedropdpwnpopup();
    this.setUpCurrentIndex = val;
    this.publicurl = '';
    this.publicurlList();
  }

  publiclink() {
    this.spinner.show();
    var tmpurl = environment.public_url + "addpubliccard/" + this.uid + "/" + this.board_id + "/" + this.setUpCurrentIndex;
    const tmp = {
      'boardid': this.board_id,
      'userid': this.uid,
      'publicurl': tmpurl,
      'index': this.setUpCurrentIndex
    }
    this.auths.savePubliUrl(tmp).subscribe(data => {
      if (data['success'] === 'true') {
        this.publicurlList();
        this.ts.show(data['msg']);
      } else { this.spinner.hide(); this.ts.info(data['msg']); }
    },
      error => {
        console.log(error);
        this.ts.error(error);
      })
  }

  publicurlList() {
    this.spinner.show();
    const tmp = {
      'boardid': this.board_id,
      'userid': this.uid,
    }
    this.auths.getPublicUrl(tmp).subscribe(data => {
      if (data['success'] === 'true') {
        this.spinner.hide(); this.publiclist = data['results'];
      } else { this.spinner.hide(); this.ts.error(data['msg']); }
    },
      error => {
        console.log(error);
        this.ts.error(error);
      })
  }

  unshareboard(val) {
    this.spinner.show();

    const tmp = {
      '_id': val
    }
    this.auths.unShareUser(tmp).subscribe(data => {
      if (data['success'] === 'true') {
        this.getshareData();
        this.spinner.hide(); this.ts.info(data['message']);
      } else { this.spinner.hide(); this.ts.error(data['message']); }
    },
      error => {
        console.log(error);
        this.ts.error(error);
      })

  }

  opencloseView(k, c, l) {
    this.kanbanView = k;
    this.calenderbln = c;
    this.listbln = l;
  }
  setFocus(val) {
    setTimeout(() => {
      $("#" + val).focus();
    }, 10);
  }

  FieldsChangeStatus(event: any, index) {
    this.statusdata[index].status = event.currentTarget.checked
    this.saveData();
  }

  FieldsChangeType(event: any, index) {
    this.typedata[index].status = event.currentTarget.checked;
    this.saveData();
  }

  changetypecolorData(e, pindex) {
    this.typedata[pindex].bcolor = e;
    this.saveData();
  }
  closetypecolordata(e, pindex) {
    this.typedata[pindex].bcolor = e;
    this.saveData();
  }

  changestatuscolorData(e, pindex) {
    this.statusdata[pindex].bcolor = e;
    this.saveData();
  }
  closestatuscolordata(e, pindex) {
    this.statusdata[pindex].bcolor = e;
    this.saveData();
  }

}