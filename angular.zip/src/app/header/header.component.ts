import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { environment } from 'src/environments/environment';

declare var $: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  imgurl:string = environment.imgUrl;
  email:string;
  img:string;
  constructor(private auth : AuthenticationService) {
    const data = JSON.parse(localStorage.getItem('currentUser'));
    this.email = data['email']; 
    
    if(data['photoUrl'] != undefined){
      this.img = data['photoUrl'];
    } else {
      this.img = environment.imgUrl + "user.png";
    }
    
   }

  ngOnInit() {
  }
  ngAfterViewInit() {
    $("ul.accountInfoWrapper a.accountToggle").click(function(){
      $(this).next().toggleClass("slideDown");
  });
  var customPopEvent = $('.popEvent');
  var closePop = $(".customPopupContent > span.icon-add");

  $(customPopEvent).click(function(){
    var getPopId = $(this).attr('data-id');
    $('.customPopup').hide();
    $('.customPopup#'+getPopId).show();
  });

  $(closePop).click(function(){
    $('.customPopup').hide();
  });
  
  }
  logout(){
    this.auth.logout();
  }

  default(val){
    if(val === 'd'){
       $(".appBoard").attr('id','mainForm');
    }else {
      $(".appBoard").attr('id','board-apple');
      
    }
  }
}
