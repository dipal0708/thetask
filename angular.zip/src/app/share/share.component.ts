import { Component, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Auth } from '../services/auth.services';
import dayGridPlugin from '@fullcalendar/daygrid';
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from 'ngx-toastr';
import { environment } from 'src/environments/environment';
declare var $: any;

@Component({
  selector: 'app-share',
  templateUrl: './share.component.html',
  styleUrls: ['./share.component.css']
})
export class ShareComponent implements OnInit {
  imgurl:string = environment.imgUrl;
  name: string;
  statusbtn: boolean = true;
  statustxt: boolean = false;
  addcard: any = [];
  cardtextbox: any = [];
  txtcardtitle: any = [];
  carddata: string;
  txttitle: string;
  carddataarr: any = [];
  mainarr: any = [];
  board_id: string;
  currentIndex: number;
  currentIndexMain: number;
  color: string = '#364f6b';
  color1: string = '#fff';
  ctitle: boolean = false;
  txttitlename: string;
  model: NgbDateStruct;
  date: { year: number, month: number };
  closeResult: any;
  ownername: string = '';
  listarr = [];
  calenderarr = [];
  viewstatus:string = 'kanban';
  calendarPlugins = [dayGridPlugin];
  lstright: string;
  txtshareemail:string;
  uid:string; 
  
  constructor(private ts : ToastrService,private spinner: NgxSpinnerService,private modalService: NgbModal, private calendar: NgbCalendar, private route: ActivatedRoute, private router: Router, private auths: Auth, private elementRef: ElementRef) {
    
  }

  ngOnInit() {
    this.spinner.show();
    this.name = this.route.snapshot.paramMap.get('name');
    this.board_id = this.route.snapshot.paramMap.get('id');
    this.getData();
  }

  addlist() {
    this.statusbtn = false;
    this.statustxt = true;
  }

 

  addcarddata(val) {
    this.addcard[val] = false;
    this.cardtextbox[val] = true;
  }
 

  getData() {
    this.auths.getAllShareBoardData(this.board_id).subscribe(data => {
      if (data['success'] === 'true') {
    
        this.mainarr = data['results']['maindata'];
        this.color = data['results']['bkccolor'];
        for (var i = 0; i <= data['results']['maindata'].length; i++) {
          this.addcard[i] = true;
          this.cardtextbox[i] = false;

        }
        this.spinner.hide();
      } else { this.spinner.hide(); }
    }, error => { console.log(error); this.spinner.hide(); })
  }
 
  changcolour(e: any) {
    this.changebackgroundcolor(e);
  }

  changebackgroundcolor(color) {
    $("#mainForm").css({'background': color });
    this.color = color; 
  }
 
  chnagetitle() {
    this.ctitle = true;
  }

  updatetitleofpage() {
    if (this.txttitlename) {
      this.auths.updatetitle(this.board_id, this.txttitlename)
        .subscribe(data => { if (data['success'] === 'true') { this.ctitle = false; this.name = this.txttitlename } })
    }
  }
  canceltitle() {
    this.ctitle = true;
  }
 
   
   
  
 
 
  selectToday() {
    this.model = this.calendar.getToday();
    
  }

  groupby(val) {
    let tmpdata = this.convertArr();
    if (val === 'status') {
      let data = [];
      let findunique = this.uniquedata(tmpdata,'status');
      let unique = findunique.sort();
      this.getGroupbyresult(unique,tmpdata,'status');
    }
    else if(val === 'dueDate'){
      let findunique = this.uniquedata(tmpdata,'dueDate');
      let unique = this.sortdate(findunique);
      this.getGroupbyresult(unique,tmpdata,'dueDate');
      
    }
  }

  sortdate(array){
    let sortedActivities = array.sort((a, b) => b.date - a.date)
    return sortedActivities;
  }
  convertArr() {
    let tmpdata = [];
    for (var i = 0; i < this.mainarr.length; i++) {
      for (var j = 0; j < this.mainarr[i].innerdata.length; j++) {
        tmpdata.push(this.mainarr[i].innerdata[j]);
      }
    }
    return tmpdata;
  }

  convertcalenderArr() {
    let tmpdata = [];
    for (var i = 0; i < this.mainarr.length; i++) {
      for (var j = 0; j < this.mainarr[i].innerdata.length; j++) {
        if(this.mainarr[i].innerdata[j].dueDate){
          tmpdata.push({'title' : this.mainarr[i].innerdata[j].textdata, 'date' :this.mainarr[i].innerdata[j].dueDate});
        }
      }
    }
    return tmpdata;
  }
  getGroupbyresult(unique,tmpdata,val){
    let data =[];
    for (var t = 0; t < unique.length; t++) {
      data[t] = [];

      for (var j = 0; j < tmpdata.length; j++) {
        if (tmpdata[j][val] === unique[t]) {
          data[t].push(tmpdata[j]);
        }
      }

    }
    for (var k = 0; k < data.length; k++) {
      if (!this.mainarr[k]) {
        this.mainarr[k] = [];
      }
      this.mainarr[k].name = (!unique[k]?'Blank':unique[k]);
      this.mainarr[k].innerdata = data[k];
    }
  }

  uniquedata(arr,val){
    const unique = [...new Set(arr.map(item => item[val]))];
    return unique;
  }
  
  closedropdown(pindex, cindex) {
    $("#editcontent" + pindex + cindex).hide();
    $("#maincontent" + pindex + cindex).show();
    $('.dropdown-menu').removeClass('show');
  }
  listView(val){
    this.viewstatus = val; 
    if(val === 'list'){
      let tmpdata = this.convertArr();
      this.listarr = tmpdata;
    
    }else if(val === 'calender'){
        this.calenderarr = this.convertcalenderArr();
    }
  }
  btnshare(){
    
  }
   
  
}
 