import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RealtimeService {
  private url = 'https://vps260154.vps.ovh.ca:4200/';
  private socket;

  constructor() { 
    this.socket = io(this.url);
  }

  public sendMessage(message) {
    this.socket.emit('userdata', message);
  }
  
public getMessages = (val) => {
  return Observable.create((observer) => {
      this.socket.on(val, (message) => {
          observer.next(message);
      });
  });
}
}
