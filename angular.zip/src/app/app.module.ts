import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { SocialLoginModule } from 'angularx-social-login';
import { AuthServiceConfig, GoogleLoginProvider  } from 'angularx-social-login';
import { BoardComponent } from './board/board.component';
import { NgDragDropModule } from 'ng-drag-drop';
import { ColorPickerModule } from 'ngx-color-picker';
import { NoSanitizePipePipe } from './no-sanitize-pipe.pipe';
import { FullCalendarModule } from '@fullcalendar/angular';
import { QRCodeModule } from 'angularx-qrcode';
import { NgxSpinnerModule } from "ngx-spinner";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 
import { ToastrModule } from 'ngx-toastr';
import { CardComponent } from './card/card.component';
import { ProfileComponent } from './profile/profile.component';
import { ShareComponent } from './share/share.component';
import { PubliccardComponent } from './publiccard/publiccard.component';
import { ChatComponent } from './chat/chat.component';
import { ChatService } from './services/chat.service';
 

const config = new AuthServiceConfig([
  {
    id: GoogleLoginProvider.PROVIDER_ID,
    provider: new GoogleLoginProvider('170471835551-gt4hpmj5e96pnt89lp078dfrlb0ahpm8.apps.googleusercontent.com')
  },
]);

export function provideConfig() {
  return config;
}


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    BoardComponent,
    NoSanitizePipePipe,
    CardComponent,
    ProfileComponent,
    ShareComponent,
    PubliccardComponent,
    ChatComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    NgxSpinnerModule,
    QRCodeModule,
    NgbModule,
    AppRoutingModule,
    SocialLoginModule,
    HttpClientModule,
    NgDragDropModule.forRoot(),
    ColorPickerModule,
    FullCalendarModule,
    BrowserAnimationsModule, // required animations module
    ToastrModule.forRoot() ,
    
    
  ],
  providers: [
    {
      provide: AuthServiceConfig,
      useFactory: provideConfig,
       
    },
    ChatService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
