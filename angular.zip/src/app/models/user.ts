export class User {
    gid: number;
    firstName: string;
    lastName: string;
    authToken: string;
    email:string;
    photoUrl:string;
    name:string;
}