import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AuthService } from 'angularx-social-login';
import { SocialUser } from 'angularx-social-login';
import { GoogleLoginProvider } from 'angularx-social-login';
import { AuthenticationService } from '../services/authentication.service';
import { Auth } from '../services/auth.services';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from 'ngx-toastr';

import { from } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Token } from '@angular/compiler/src/ml_parser/lexer';
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, AfterViewInit {
  user: SocialUser;
  closeResult: any;
  id: any;
  myAngularxQrCode: string = null;
  uuid: string;
  passcode: string;
  scanstatus: boolean = false;
  imgurl: string = environment.imgUrl;

  constructor(private ts: ToastrService, private spinner: NgxSpinnerService, private router: Router, private modalService: NgbModal, private authService: AuthService, private auth: AuthenticationService, private auths: Auth) {
    let data = localStorage.getItem('currentUser');
    if (data) {
      this.router.navigate(['dashboard']);
    }
  }

  ngOnInit() {
    this.authService.authState.subscribe((user) => {
      this.user = user;
   
      this.getacesstoken();
      
    });

  }

  ngAfterViewInit() {
    // $(".mainLoginWrapper").height($(window).height());
    // $(".btnSignin").click(function () {
    //   $(this).parent().addClass("active");
    //   $(this).parent().next().slideDown();
    //   $(".loginWindowWrapper").addClass("removeOpacity");
    // });

    /*=== Custom Popup ===*/

    // var customPopEvent = $('.popEvent');
    // var closePop = $(".customPopupContent > span.icon-add");

    // $(customPopEvent).click(function () {

    //   var getPopId = $(this).attr('data-id');

    //   $('.customPopup').hide();
    //   $('#' + getPopId).show();
    // });

    // $(closePop).click(function () {
    //   $('.customPopup').hide();
    // });

    // $(document).mouseup(e => {
    //   if (
    //     !$('.customPopupContent').is(e.target) && // if the target of the click isn't the container...
    //     $('.customPopupContent').has(e.target).length === 0) {
    //     // ... nor a descendant of the container
    //     $('.customPopup').hide();
    //   }
    // });
  }

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then(x => { this.checkLoginData(x) });
  }

  checkLoginData(data) {
    this.spinner.show();
    this.auths.addUser(data).subscribe(data => {
      if (data['success'] === 'true') {
        this.ts.success('Login Successfully');
        this.auth.login(data['organizerRecord'], data['token'], data['_id'])
      } else { console.log('something went wrong'); }
    }, error => { console.log(error); })
  }

  popupstartApi() {
    this.calllogintimer();
  }

  signInWithAkcess() {
    const apidata = {
      api: "48edeeb2c87c0e0a8ab51f02fd3db409",
      AKcessToken : localStorage.getItem("accesstoken")
    }
    this.auths.generateqrcode(apidata).subscribe(data => {
      if (data['status'] === 1) {
        this.uuid = data['data'].webUUID;
        var n = JSON.stringify(data['data']);
        this.myAngularxQrCode = n;
        this.calllogintimer();
      }
    })
  }

  // open1(content) {
  //   this.calllogintimer();
  //   this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
  //     this.closeResult = `Closed with: ${result}`;
  //     clearInterval(this.id);
  //   }, (reason) => {
  //     //this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  //   });
  // }

  calllogintimer() {
    this.id = setInterval(() => { this.logincheckService(); }, 3000);
  }

  logincheckService() {
    const uuidData = { uuid: this.uuid,api: "48edeeb2c87c0e0a8ab51f02fd3db409", AKcessToken : localStorage.getItem("accesstoken")  };
    this.auths.scanloginstatus(uuidData).subscribe(data => {
      if (data['status'] === 1) {
        clearInterval(this.id);
        this.scanstatus = true;
      }
    })
  }
  signInWithAkcesspopup() {

  }

  clickpasscode() {
    if (this.passcode) {
      this.spinner.show();
      const data = { passCode: this.passcode, uuid: this.uuid , api: "48edeeb2c87c0e0a8ab51f02fd3db409", AKcessToken : localStorage.getItem("accesstoken") }
      this.auths.loginuser(data).subscribe(data => {
        if (data['status'] === 1) {
          const tmpdata = {
            'AccessToken': data['data'].AccessToken,
            'userId': data['data'].UserId,
            'UserName': data['data'].UserName,
            'email': data['data'].userEmail,
            'phone': data['data'].userPhone
          }

          this.checkLoginData(tmpdata);

          this.modalService.dismissAll();
        } else {
          this.spinner.hide();
          this.ts.error(data['message']);
        }
      })
    } else {
      this.spinner.hide();
      this.ts.info('Enter passCode');
    }
  }

  getacesstoken() {
    const apidata = {
      api: "48edeeb2c87c0e0a8ab51f02fd3db409"
    }
    this.auths.acesstoken(apidata).subscribe(data => {
      console.log("data", data);

      localStorage.setItem("accesstoken", data["token"]);
      this.signInWithAkcess();

    })
  }
   
}
