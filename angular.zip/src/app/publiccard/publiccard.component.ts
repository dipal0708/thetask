import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Auth } from '../services/auth.services';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-publiccard',
  templateUrl: './publiccard.component.html',
  styleUrls: ['./publiccard.component.css']
})
export class PubliccardComponent implements OnInit {
  imgurl:string = environment.imgUrl;
  mainarr:any = [];
  name:string;
  txtdata:string;
  board_id:string;
  userid:string;
  index:string;
  txtname: string;
  txtemail: string;
  txttask: string;


  constructor(private ts : ToastrService,private spinner: NgxSpinnerService,private auth : Auth,private route: ActivatedRoute) { }
  ngOnInit() {
    this.board_id = this.route.snapshot.paramMap.get('baordid');
    this.userid =this.route.snapshot.paramMap.get('userid');
    this.index =this.route.snapshot.paramMap.get('index');
  }

  savepublicData(){
    
      if(this.txtname && this.txtemail && this.txttask){
        this.spinner.show();
          const data = {
            'textdata': this.txttask,
            'cardid': this.auth.random(),
            'boardid': '',
            'createdDate': Date.now(),
            'createdBy': this.txtname,
            'owner': this.txtemail,
            'color': '#fff',
            'list': '',
            'status': '',
            'dueDate': '',
            'shares': '',
            'other': '',
            'type': '',
            'link':true,
            'datepicker': false
          }
          const userdata = {
            'boardid' : this.board_id,
            'userid' : this.userid,
            'index' : this.index
          }
          const maindata = {'card':data,'userdata':userdata};
          this.auth.addpubliccard(maindata).subscribe(data => { 
              this.spinner.hide();
            if(data['success'] === 'true') { 
              this.ts.success(data['msg']);
              this.txtname =''; this.txtemail='';this.txttask ='';
            } else { 
                this.ts.error(data['msg']); } }, error => { console.log(error); this.spinner.hide(); })
      }else {
        
        this.ts.error('Please enter all input');
      }
  }


}
