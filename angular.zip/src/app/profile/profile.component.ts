import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { environment } from 'src/environments/environment';

declare var $: any;

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  imgurl:string = environment.imgUrl;
  email:string;
  img:string;
  fname:string;
  lname:string;
  fullname:string;
  constructor(private auth : AuthenticationService) {
    const data = JSON.parse(localStorage.getItem('currentUser'));
    
    this.fullname = data['firstName'] + ' ' + data['lastName'];
    this.fname = data['firstName'];
    this.lname = data['lastName'];
    this.email = data['email'];
    this.img = data['photoUrl'];
   }
  

  ngOnInit() {

  }

  ngAfterViewInit() {
    $('.profileNavWrapper a[data-toggle="tab"]').on('click', function (e) {
      e.preventDefault();
      var getId = $(e.target).attr('data-id');
      var $curr = $(".profileNavWrapper a[data-id='" + getId + "']").parent();

      $('.profileNavWrapper li').removeClass('active');
      $('.profileNavWrapper li').removeClass('visited');
      $('.profileTabContentWrapper .proContent').removeClass('active');

      $curr.addClass("active");
      $curr.prevAll().addClass("visited");
      $('.profileTabContentWrapper .proContent#'+getId).addClass("active");
  });

  $('.leftSideListItems a').on('click', function (e) {
    e.preventDefault();
    var getId = $(e.target).attr('data-id');
    var $curr = $(".leftSideListItems a[data-id='" + getId + "']").parent();

    $('li.leftSideListItems').removeClass('active');
    $('.rightContainer').removeClass("active");

    $curr.addClass("active");
    $('.rightContainer#'+getId).addClass("active");
});
  }

}
