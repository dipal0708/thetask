import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../services/auth.services';
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  constructor(private ts : ToastrService,private spinner: NgxSpinnerService,private router: Router,private auths : Auth) { }

  ngOnInit() {
  }
  authClick(){
      const tmpdata = JSON.parse(localStorage.getItem('currentUser'));
      
    this.auths.getcontactlist(tmpdata).subscribe(data => { if(data['success'] ==='true'){     } else { console.log('something went wrong'); } }, error => { console.log(error); })
  }

}
