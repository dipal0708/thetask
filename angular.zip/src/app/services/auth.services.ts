import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { User } from '../models/user';
 

@Injectable({ providedIn: 'root' })

export class Auth {
    httpOptions:any;
    token:any;
    userid:any;
    constructor(private http: HttpClient) {
       
     }
     getAuthData(){
      this.token = localStorage.getItem('token');
      this.userid =  localStorage.getItem('id');
      
      this.httpOptions = {
          headers: new HttpHeaders({
              'Content-Type' : 'application/json',
              'x-access-token' : this.token
          })     
      }
     }

      addUser (user: User): Observable<User> {
        return this.http.post<User>(environment.url + "api/authenticate", user);
      }
      adddashboardtitle(titlename){
        this.getAuthData();
          return this.http.post<any>(environment.url + "api/addBoardName", JSON.stringify({'id':this.userid,'title': titlename}),this.httpOptions)
      }
      getBoardData(){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/getBoardData", JSON.stringify({'id':this.userid}),this.httpOptions)
      }
      getPantagoneData(){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/getPantangoneData", JSON.stringify({'id':this.userid}),this.httpOptions)
      }
      saveBoardData(data){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/saveBoardData", JSON.stringify(data),this.httpOptions)
      }
      getAllBoardData(boardid){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/getBoard", JSON.stringify({'boardid':boardid}),this.httpOptions)
      }
      getAllShareBoardData(boardid){
        this.httpOptions = {
          headers: new HttpHeaders({
              'Content-Type' : 'application/json',
          })     
      }
          return this.http.post<any>(environment.url + "api/getShareBoard", JSON.stringify({'boardid':boardid}),this.httpOptions)
      }
      updatetitle(boardid,title){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/changetitle", JSON.stringify({'boardid':boardid,'title':title}),this.httpOptions)
      }
      deleteboard(id){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/deleteBoard", JSON.stringify({'boardid':id}),this.httpOptions)
      }
      random(){
        return Math.floor((Math.random()*1000000)+1);
      }
      getstatusData(){
        var statusData = [{'name':'New', 'status':true,'bcolor' : '#007bff'},{'name':'In Progress', 'status':true,'bcolor' : '#ffc107'},{'name':'Complete', 'status':true,'bcolor':'#28a745'},{'name':'Close', 'status':true,'bcolor':'#dc3545'}];
          return statusData;
      }
      getTypeData(){
        var typeData = [{'name':'Bug', 'status':true, 'bcolor' : '#dc3545'},{'name':'Issue', 'status':true, 'bcolor' : '#ffc107'},{'name':'Documentation', 'status':true, 'bcolor' : '#6c757d'},{'name':'Info', 'status':true, 'bcolor' : '#17a2b8'},{'name':'Other', 'status':true, 'bcolor' : '#343a40'}]
        return typeData;
      }
      // getQrData(){
      //   return this.http.post<any>(environment.urlAkcess + "get3rdPartyLoginUUID",'');
      // }
      // loginstatus(uuid){
      //   return this.http.post<any>(environment.urlAkcess + "scanLoginStatus",uuid);
      // }
      // partyLogin(data){
      //   return this.http.post<any>(environment.urlAkcess + "do3rdPartyLogin",data);
      // }
      getcontactlist(data){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/getContactList", JSON.stringify(data),this.httpOptions)
      }
      shareBoardViaEmail(data){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/pushShareEmail", JSON.stringify(data),this.httpOptions)
      }
      getSharedEmail(data){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/getshareemail", JSON.stringify(data),this.httpOptions)
      }
      savePubliUrl(data){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/addpublicurl", JSON.stringify(data),this.httpOptions)
      }
      getPublicUrl(data){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/getpublicurldata", JSON.stringify(data),this.httpOptions)
      }
      unShareUser(data){
        this.getAuthData();
        return this.http.post<any>(environment.url + "api/unsharedata", JSON.stringify(data),this.httpOptions)
      }
      addpubliccard(data){
        this.httpOptions = {
          headers: new HttpHeaders({
              'Content-Type' : 'application/json',
          })     
      }
        return this.http.post<any>(environment.url + "api/savepublicurldata", JSON.stringify(data),this.httpOptions)
      }

      acesstoken(data){
        var dataauthtemp = {
          headers: new HttpHeaders({
              'Content-Type' : 'application/json'
          })     
      }
        return this.http.post<any>(environment.urlAkcessapi + "getToken", JSON.stringify(data),dataauthtemp)
      }

      generateqrcode(data){ 
         var qrcodedata = {
          headers: new HttpHeaders({
              'Content-Type' : 'application/json'
          })     
      }
        return this.http.post<any>(environment.urlAkcessapi + "generateQrCode", JSON.stringify(data),qrcodedata)
      }
      scanloginstatus(data){
        var scanlogindata = {
          headers: new HttpHeaders({
              'Content-Type' : 'application/json'
          })     
      }
        return this.http.post<any>(environment.urlAkcessapi + "scanLoginStatus", JSON.stringify(data),scanlogindata)
      }

      loginuser(data){
        var loginuserdata = {
          headers: new HttpHeaders({
              'Content-Type' : 'application/json'
          })     
      }
        return this.http.post<any>(environment.urlAkcessapi + "loginUser", JSON.stringify(data),loginuserdata)
      }
} 