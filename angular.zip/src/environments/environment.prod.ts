export const environment = {
  production: true,
  url : 'https://vps260154.vps.ovh.ca:4200/',
  //url : 'http://localhost:4200/',
  imgUrl  : 'https://www.thetaskwiz.com/task/assets/images/',
  urlAkcess: 'https://dev.akcess.io:3000/',
  emailUrl : 'https://thetaskwiz.com/task/',
  public_url : 'https://thetaskwiz.com/task/'
};