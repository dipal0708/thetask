// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false, 
 //url : 'https://vps260154.vps.ovh.ca:4200/',
  url : 'http://localhost:3000/',
  // imgUrl  : 'https://www.thetaskwiz.com/task/assets/images/',
  imgUrl  : 'http://localhost:4200/assets/images/',
  //urlAkcess: 'https://mobile.akcess.dev:3000/',
  urlAkcess: 'https://dev.akcess.io:3000/',
  urlAkcessapi:'https://ak-api.akcess.dev/api/v1/',
  emailUrl : 'https://thetaskwiz.com/task/',
  // public_url : 'http://localhost:4200/',
  public_url : 'https://thetaskwiz.com/task/'
}; 

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
